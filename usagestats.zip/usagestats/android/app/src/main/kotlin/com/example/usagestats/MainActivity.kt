package com.example.usagestats

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
